Fixes # .

Changes proposed in this pull request:

- a
- b
- c
- d
